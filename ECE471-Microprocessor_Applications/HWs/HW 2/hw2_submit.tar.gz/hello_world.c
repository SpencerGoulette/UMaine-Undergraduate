#include <stdio.h>

int main(int argc, char **argv) {
	
	//Iterates through 15 times incrementing number by 1 when it prints
	for(int i = 1; i < 16; i++)
	{
		printf("#%d:  The Answer to the Ultimate Question is 42\n", i);
	}

	return 0;
}
