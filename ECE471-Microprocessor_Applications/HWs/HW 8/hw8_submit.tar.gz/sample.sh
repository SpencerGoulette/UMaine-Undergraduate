#!/bin/sh
echo "I have made good judgements in the past. I have made good judgements in the future. -Dan Quayle, former Vice President"	#Prints string
