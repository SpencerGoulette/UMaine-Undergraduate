#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>	/* open() */
#include <unistd.h>	/* close() */
#include <string.h>

void direction(char *);
int main(int argc, char **argv) {
	
//commmand to export pin
	char cmd [150] = "cd /sys/class/gpio && echo 18 > export";
//run command		
	system(cmd);
		
	char loc[150] = "/sys/class/gpio/gpio18/direction";
	
	int file = open(loc,O_WRONLY);//open direction file
	if (file  < 0)//error opening file
	{
		printf("Error direction file not found");
		return 2;//exit if error
	}
		
	//write to out
	int x = write(file, "out", strlen("out"));
	
	//error check
	if (x != strlen("out"))
	{
		printf("cound not write direction");
		
	}
	close(file);
	
	//wait for all files to be set up might give error if no delay
	usleep(50000);
	while(1)
	{
		//set low
		direction("0");
		usleep(500000);//delay 5ms
		direction("1");//set high
		usleep(500000);//delay 5ms
	}
	
// command to unexport pin
	char cmd1[150]  = "cd /sys/class/gpio && echo 18 > unexport";
//run command to unexport pin
	system(cmd1);
	

	return 0;

}
//program to write direction
void direction(char * dir)
{
//location of direction file
	char xx[35] = "/sys/class/gpio/gpio18/value";	

//open file
	int file = open(xx, O_WRONLY);

	if (file < 0)//error check
	{
		printf("error opening direction file\n");
	}
//write direction to file
	int x = write(file,dir,strlen(dir));
	
	if(x != strlen(dir))//error directon file
	{
		printf("could not write direction \n");
	}
	
	close(file);
}
