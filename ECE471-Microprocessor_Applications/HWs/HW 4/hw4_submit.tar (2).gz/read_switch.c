#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>	/* open() */
#include <unistd.h>	/* close() */
#include <string.h>

void direction(char *);
int main(int argc, char **argv) {
	
//commmand to export pin
	char cmd [150] = "cd /sys/class/gpio && echo 17 > export";
//run command		
	system(cmd);
		
	char loc[150] = "/sys/class/gpio/gpio17/direction";
		
	usleep(50000);
		
	int file = open(loc,O_WRONLY);//open direction file
	if (file  < 0)//error opening file
	{
		printf("Error direction file not found");
		return 2;//exit if error
	}
		
	//write to out
	int x = write(file, "in", strlen("in"));
	
	//error check
	if (x != strlen("in"))
	{
		printf("cound not write direction");
		
	}
	close(file);
	
	//wait for all files to be set up might give error if no delay
	usleep(50000);
	int fd,fdd;
	char buffer [16];	
	
	while(1)
	{
		fd = open("/sys/class/gpio/gpio17/value", O_RDONLY);
//	while(1)
//	{
		
		if (fd < 0)
		{
			printf("error opening value file\n");
		}
		read(fd,buffer,17);
		close(fd);
		
		if (buffer[0] == '1')
		{
			printf("Pressed\n");
			while(buffer[0] != '0')
			{	
				fdd = open("/sys/class/gpio/gpio17/value",O_RDONLY);
				read(fd, buffer, 16);
				close(fdd);	
			}
			printf("Released\n");
		}

		
	}

	
	return 0;

}
